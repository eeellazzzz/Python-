import matplotlib.pyplot as plt
import pandas as pd

df = pd.read_csv('ekb_weather.csv')
print(df.head(10))