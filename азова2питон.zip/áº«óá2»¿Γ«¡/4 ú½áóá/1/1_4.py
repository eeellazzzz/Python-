import matplotlib.pyplot as plt
import pandas as pd

df = pd.read_csv('ekb_weather.csv')
months = {1:'Январь', 2:'Февраль', 3:'Март', 4:'Апрель', 5:'Май', 6:'Июнь', 7:'Июль', 8:'Август', 9:'Сентябрь', 10:'Октябрь', 11:'Ноябрь', 12:'Декабрь'}

df['date'] = pd.to_datetime(df['date'])
df['month'] = pd.DatetimeIndex(df['date']).month

#Использование собственной функции
df['month'] = df['month'].apply(lambda i: months[i])

df.to_csv('new_ekb_weather.csv')

print(df)


#Использование встроенных методов
#df['date'] = pd.to_datetime(df['date'])
#df['month'] = df['date'].dt.month
#df['month'] = pd.to_datetime(df['month'], format='%m').dt.month_name()
#print(df)

#df['date'] = pd.to_datetime(df['date'])
#df["month"] = pd.to_datetime(df["Date"]).dt.month
#df["month"] = pd.to_datetime(df["date"]).dt.strftime("%B")