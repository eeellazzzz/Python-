import matplotlib.pyplot as plt
import pandas as pd

df = pd.read_csv('iris-virginica.csv')

print(df)

df.plot(x = 'sepal_len', y = 'sepal_wd', kind = 'scatter',
title = 'sepal_len/sepal_wd')
plt.show()

df.plot(x = 'petal_len', y = 'petal_wd', kind = 'scatter',
title = 'petal_len/petal_wd')
plt.show()