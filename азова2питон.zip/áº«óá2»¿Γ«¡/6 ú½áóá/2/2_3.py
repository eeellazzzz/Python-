import pandas as pd
import numpy as np
import json

with open('peoples.json') as f:
    peoples = json.load(f)

stdr = np.std(list(peoples['heights'].values()))
print('Ст. откл.[heights]', stdr)

disp = np.var(list(peoples['heights'].values()))
print('Дисперсия[heights]', disp)

stdr1 = np.std(list(peoples['weights'].values()))
print('Ст. откл.[weights]', stdr1)

disp1 = np.var(list(peoples['weights'].values()))
print('Дисперсия[weights]', disp1)

stdr2 = np.std(list(peoples['ages'].values()))
print('Ст. откл.[ages]', stdr2)

disp2 = np.var(list(peoples['ages'].values()))
print('Дисперсия[ages]', disp2)