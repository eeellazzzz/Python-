import pandas as pd
import json

with open('peoples.json') as f:
    peoples = json.load(f)
    
print(peoples['heights'].values())    